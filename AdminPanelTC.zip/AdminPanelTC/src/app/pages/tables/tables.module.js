(function () {
    'use strict';

    angular.module('BlurAdmin.pages.tables', [])
        .config(routeConfig);

    /** @ngInject */
    function routeConfig($stateProvider, $urlRouterProvider) {

    }

})();
